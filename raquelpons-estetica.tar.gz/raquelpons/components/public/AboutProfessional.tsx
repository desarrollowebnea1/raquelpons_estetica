'use client'
// components/public/AboutProfessional.tsx
import { motion } from 'framer-motion'
import { Award } from 'lucide-react'

interface AboutProps {
  settings: {
    aboutText: string
    trainingText: string
    experienceText: string
    brandName: string
  }
}

export default function AboutProfessional({ settings }: AboutProps) {
  return (
    <section id="formacion" className="section-padding bg-parchment">
      <div className="container-premium">
        <div className="grid lg:grid-cols-2 gap-16 items-center">
          {/* Texto */}
          <motion.div
            initial={{ opacity: 0, x: -24 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.7 }}
          >
            <p className="section-label mb-6">La profesional</p>
            <h2 className="font-display text-4xl md:text-5xl text-anthracite mb-6 leading-tight">
              Un enfoque integral
              <br />
              <em className="text-elegantBrown">del cuidado de la piel</em>
            </h2>
            <div className="w-16 h-px bg-champagne mb-8" />
            <p className="font-sans text-base text-anthracite/70 leading-relaxed mb-8">
              {settings.aboutText}
            </p>

            <div className="space-y-4">
              <div className="flex gap-4 items-start p-4 bg-warmWhite rounded-soft border border-[rgba(44,44,44,0.06)]">
                <Award size={18} className="text-champagne flex-shrink-0 mt-0.5" strokeWidth={1.5} />
                <div>
                  <p className="font-sans text-xs font-medium text-anthracite mb-1">Formación</p>
                  <p className="font-sans text-sm text-anthracite/65">{settings.trainingText}</p>
                </div>
              </div>

              <div className="flex gap-4 items-start p-4 bg-warmWhite rounded-soft border border-[rgba(44,44,44,0.06)]">
                <Award size={18} className="text-champagne flex-shrink-0 mt-0.5" strokeWidth={1.5} />
                <div>
                  <p className="font-sans text-xs font-medium text-anthracite mb-1">Experiencia</p>
                  <p className="font-sans text-sm text-anthracite/65">{settings.experienceText}</p>
                </div>
              </div>
            </div>
          </motion.div>

          {/* Visual card */}
          <motion.div
            initial={{ opacity: 0, x: 24 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.7, delay: 0.1 }}
            className="relative"
          >
            {/* Imagen placeholder premium */}
            <div className="aspect-[3/4] max-w-sm mx-auto lg:mx-0 lg:ml-auto rounded-soft bg-gradient-to-br from-nude via-champagne/30 to-dustyRose/40 flex items-end overflow-hidden relative">
              <div className="absolute inset-0 flex items-center justify-center text-center p-8 opacity-30">
                <div className="space-y-3">
                  <div className="w-20 h-20 mx-auto rounded-full border border-champagne" />
                  <p className="font-display italic text-2xl text-elegantBrown">
                    {settings.brandName.split('_')[0]}
                  </p>
                </div>
              </div>
              <div className="relative z-10 p-6 bg-gradient-to-t from-anthracite/80 to-transparent w-full">
                <p className="font-sans text-xs text-warmWhite/80 tracking-wide mb-1">
                  Córdoba, Argentina
                </p>
                <p className="font-display text-lg text-warmWhite">
                  Estética Profesional & Dermocosmética
                </p>
                <p className="font-sans text-xs text-champagne mt-2 tracking-wide">
                  Formación Internacional · España
                </p>
              </div>
            </div>

            {/* Badge decorativo */}
            <div className="absolute -bottom-4 -left-4 bg-warmWhite rounded-soft shadow-medium px-5 py-3 border border-[rgba(44,44,44,0.06)]">
              <p className="font-sans text-[10px] tracking-wide text-anthracite/50 uppercase mb-0.5">Consulta con</p>
              <p className="font-display text-sm font-medium text-anthracite">María Padilla</p>
              <p className="font-sans text-[10px] text-elegantBrown">Barcelona, España</p>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  )
}
